<?php
/*
Element Description: Point Table
*/
    
    function find_club($clubname){
		$args =new wp_Query(array(
		    'post_type' => 'club',  
		    'p' => $clubname       
		));		
  	
		if ( $args->have_posts() ) {		
		  $team = get_the_title($clubname);
		  return $team;		 
		  wp_reset_query();                           
		}
	}

    function vc_Portfolio_mapping() {
         
        // Stop all if VC is not enabled
        if ( !defined( 'WPB_VC_VERSION' ) ) {
            return;
        }
        
        $category_dropdown = array( __( 'All Categories', 'rsaddon' ) => '0' );	
        $args = array(
            'taxonomy' => array('league-category'),//ur taxonomy
            'hide_empty' => true,                  
        );

		$terms_= new WP_Term_Query( $args );
		foreach ( (array)$terms_->terms as $term ) {
			$category_dropdown[$term->name] = $term->slug;		
		}

        // Map the block with vc_map()
        vc_map( 
            array(
                'name' => __('Point Table Box', 'rsaddon'),
                'base' => 'vc_pointtable',
                'description' => __('Point Table Information', 'rsaddon'), 
                'category' => __('by RS Theme', 'rsaddon'),   
                'icon' => get_template_directory_uri().'/framework/assets/img/vc-icon.png',           
                'params' => array(

                    array(
                    	"type" => "dropdown",
                    	"heading" => __("Point Table Style", "rsaddon"),
                    	"param_name" => "pointtable",
                    	"value" => array(	                    	
                    		__("Default Style", "rsaddon") => "1",
                    		__("Sidebar Style", "rsaddon") => "2"
                    		
                    	),
                    	"description" => __("Select your style here", "rsaddon"),                    	
                    ),

                    
                    array(
						"type" => "dropdown_multi",
						"holder" => "div",
						"class" => "",
						"heading" => __( "Select Categories", 'rsaddon' ),
						"param_name" => "cat",
						'value' => $category_dropdown,
					),

					 array(
                    	"type" => "textfield",
                    	"heading" => __("Result Per Page", "rsaddon"),
                    	"param_name" => "pointtable_result",                    	               	
                    ),

					array(
						"type"               => "dropdown",
						"heading"            => __("Show Team Logo", "rsaddon"),
						"param_name"         => "show_tem_logo",
						"value"              => array(	                    	
						__("No", "rsaddon")  => "no",
						__("Yes", "rsaddon") => "yes"
						
						),
						"dependency"         => Array('element' => 'pointtable', 'value' => array('2')),                	
						),
						
							
					array(
						"type"        => "colorpicker",
						"class"       => "",
						"heading"     => __( "Heading Bg Color", "rsaddon" ),
						"param_name"  => "head_bg_colors",
						"value"       => '',
						"description" => __( "Choose Heading Bg Color", "rsaddon" ),
						'group'       => 'Styles',
					),


             		array(
						"type"        => "colorpicker",
						"class"       => "",
						"heading"     => __( "Heading Text color", "rsaddon" ),
						"param_name"  => "head_text_color",
						"value"       => '',
						"description" => __( "Choose Heading Text color", "rsaddon" ),
						'group'       => 'Styles',
					),

					array(
						"type"       => "colorpicker",
						"class"      => "",
						"heading"    => __( "Even Row Bg Color", "rsaddon" ),
						"param_name" => "even_row",
						"value"      => '',						
						'group'      => 'Styles',
					),
					

					array(
						"type"       => "colorpicker",
						"class"      => "",
						"heading"    => __( "Odd Row Bg Color", "rsaddon" ),
						"param_name" => "odd_row",
						"value"      => '',						
						'group'      => 'Styles',
					),				


             		array(
						"type"        => "colorpicker",
						"class"       => "",
						"heading"     => __( "Even Row Text color", "rsaddon" ),
						"param_name"  => "text_color",
						"value"       => 'fff',
						"description" => __( "Choose text color", "rsaddon" ),
						'group'       => 'Styles',
					),

					array(
						"type"        => "colorpicker",
						"class"       => "",
						"heading"     => __( "Odd Row Text color", "rsaddon" ),
						"param_name"  => "odd_text_color",
						"value"       => 'fff',
						"description" => __( "Choose text color", "rsaddon" ),
						'group'       => 'Styles',
					),

					array(
						'type'        => 'textfield',
						'heading'     => __( 'Extra class name', 'js_composer' ),
						'param_name'  => 'el_class',
						'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'rsaddon' ),
					),
					
					array(
					'type'       => 'css_editor',
					'heading'    => __( 'CSS box', 'rsaddon' ),
					'param_name' => 'css',
					'group'      => __( 'Design Options', 'rsaddon' ),
				),            
                        
                ),				
					
            )
        );                                
        
    }
     add_action( 'vc_before_init', 'vc_Portfolio_mapping' );
     
    // Element HTML
     function vc_Portfolio_html( $atts,$content ) {
         $attributes = array();
        // Params extraction
        extract(
            shortcode_atts(
                array(						
					'pointtable'        => '1',		
					'text_color'        => '#fff',	
					'odd_text_color'    => '',
					'odd_row'           => '',
					'even_row'          => '',				
					'head_bg_colors'    => '#214790',					
					'head_text_color'   => '#fbc02d',					
					'el_class'          => '',
					'pointtable_result' => -1,					
					'css'               => '',
					'cat'               => '',					
					'show_tem_logo'     => '',					
                ), 
                $atts,'vc_pointtable'
           )
        );

        $taxonomy = '';		
		
		//extact icon 		
		//extract css edit box
		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );
		
		//custom class added
		$wrapper_classes  = array($el_class) ;			
		$class_to_filter  = implode( ' ', array_filter( $wrapper_classes ) );		
		$css_class_custom = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class_to_filter, $atts );
  		
		
		$head_text_color = ($head_text_color) ? ' style="color: '.$head_text_color.'"' : '';
		
		
		$point_table_localize_data  = array(
			'even'      => $even_row,
			'even_text' => $text_color,
			'odd_text'  => $odd_text_color,
			'odd'       => $odd_row,
			'heading_bg' => $head_bg_colors
		);
		
		wp_localize_script( 'khelo-main', 'point_table_row', $point_table_localize_data );   
     
		if($pointtable == 1){

        $html ='<div class="rs-portfolio-style pointable">
		<div class="'.$css_class.'">';
        // Get taxonomy form portfolio
       		
        $html .='<table>

        <tr class="bg-colors">
        	<th></th>
       		<th '.$head_text_color.'>'.esc_html__('Team', 'rsaddon').'</th>       		
       		<th '.$head_text_color.'>'.esc_html__('P', 'rsaddon').'</th>   
       		<th '.$head_text_color.'>'.esc_html__('W', 'rsaddon').'</th>   
       		<th '.$head_text_color.'>'.esc_html__('D', 'rsaddon').'</th>   
       		<th '.$head_text_color.'>'.esc_html__('L', 'rsaddon').'</th>   
       		<th '.$head_text_color.'>'.esc_html__('GS', 'rsaddon').'</th>   
       		<th '.$head_text_color.'>'.esc_html__('GA', 'rsaddon').'</th>   
       		<th '.$head_text_color.'>'.esc_html__('GD', 'rsaddon').'</th>   
       		<th '.$head_text_color.'>'.esc_html__('PTS', 'rsaddon').'</th>   
       	</tr>

        '; 
         //******************//
        // query post
        //******************//
    		$cat;
            $arr_cats = array();
            $arr= explode(',', $cat);
				for ($i=0; $i < count($arr) ; $i++) { 
               	//$cats = get_term_by('slug', $arr[$i], $taxonomy);
               	// if(is_object($cats)):
               	$arr_cats[]= $arr[$i];
               	//endif;
            }

      		if(empty($cat)){
	        	$best_wp = new wp_Query(array(
						'post_type' => 'point-table',						
						'posts_per_page' => $pointtable_result,
						 'meta_query' => array(
			        	'relation' => 'AND',
				        'points_clause' => array(
				            'key' => 'total_points',
				            'compare' => 'EXISTS',
				            'type'      => 'NUMERIC'
				        ),
				        'gd_clause' => array(
				            'key' => 'goal_difference',
				            'compare' => 'EXISTS',
				            'type'      => 'NUMERIC'

				        ), 
				    ),
					      
				     'orderby' => array( 
					        'points_clause' => 'meta_value_num',
					        'gd_clause' => 'meta_value_num',
					    ),
				      'order' => 'DESC',


					
						
				));	  
	        }

	        else{
            
		    $best_wp = new wp_Query(array(
					'post_type' => 'point-table',					
					'posts_per_page' => $pointtable_result,		

					 'order'          => 'DESC',													
					'tax_query' => array(
				        array(
				            'taxonomy' => 'league-category',
				            'field' => 'slug', //can be set to ID
				            'terms' => $arr_cats//if field is ID you can reference by cat/term number
				        ),
				    ),
				    'meta_query' => array(
			        	'relation' => 'AND',
				        'points_clause' => array(
				            'key' => 'total_points',
				            'compare' => 'EXISTS',
				            'type'      => 'NUMERIC'
				        ),
				        'gd_clause' => array(
				            'key' => 'goal_difference',
				            'compare' => 'EXISTS',
				            'type'      => 'NUMERIC'

				        ), 
				    ),
					      
				     'orderby' => array( 
					        'points_clause' => 'meta_value_num',
					        'gd_clause' => 'meta_value_num',
					    ),

				      'order' => 'DESC',


				));
			}	
			$x = 1;
       			if( $best_wp->have_posts() ): while( $best_wp->have_posts() ) : $best_wp->the_post(); //start while loop

			   $clubname = get_post_meta( get_the_ID(), 'team_point',true );

			   
			   $post_title = get_the_title($best_wp->ID);			  
			 	
			    $post_img_url = get_the_post_thumbnail_url($best_wp->ID,'full');
			    $post_url=get_post_permalink($best_wp->ID); 
				
			
						
				$html .='				

                   <tr>
                   		<td>'.$x.'</td>

                   		<td>'.find_club($clubname).'</td>';

                        $html .='      	                                   		
                   		<td>'.get_post_meta( get_the_ID(), 'game_player',true ).'</td>
                   		<td>'.get_post_meta( get_the_ID(), 'game_won',true ).'</td>
                   		<td>'.get_post_meta( get_the_ID(), 'game_drown',true ).'</td>
                   		<td>'.get_post_meta( get_the_ID(), 'game_lost',true ).'</td>
                   		<td>'.get_post_meta( get_the_ID(), 'goal_scored',true ).'</td>
                   		<td>'.get_post_meta( get_the_ID(), 'goal_against',true ).'</td>
                   		<td>'.get_post_meta( get_the_ID(), 'goal_difference',true ).'</td>
                   		<td>'.get_post_meta( get_the_ID(), 'total_points',true ).'</td>
                   </tr>';                                          

					$x++;
						endwhile; 
				wp_reset_query();
			endif;
			
		$html .= '
		</table>

		</div>
		</div>';		
	  return $html; 
    }

else {
	 if($show_tem_logo == 'yes'){ 
    	$first_head = '';
    }else{
    	$first_head = '<th></th>';
    }
	$html ='<div class="rs-portfolio-style style2 pointable">
		<div class="style2-bg '.$css_class.'">';
        // Get taxonomy form portfolio       		
        $html .='<table '.$text_color.'>
        <tr class="bg-colors">'.$first_head.'
       		<th '.$head_text_color.'>'.esc_html__('Team', 'rsaddon').'</th>      		  
       		<th '.$head_text_color.'>'.esc_html__('W', 'rsaddon').'</th>      		  
       		<th '.$head_text_color.'>'.esc_html__('L', 'rsaddon').'</th>
       		<th '.$head_text_color.'>'.esc_html__('PTS', 'rsaddon').'</th>   
       </tr>
        '; 
         //******************//
        // query post
        //******************//
    		$cat;
            $arr_cats = array();
            $arr= explode(',', $cat);
				for ($i=0; $i < count($arr) ; $i++) {                	
               	$arr_cats[]= $arr[$i];              
            }
      		if(empty($cat)){
	        	$best_wp = new wp_Query(array(
						'post_type' => 'point-table',
						'meta_key' => 'total_points',
						'orderby' => 'meta_value_num',
						'posts_per_page' => $pointtable_result,
						'order' => 'DSC' 							
						
				));	  
	        }

	        else{
            
		    $best_wp = new wp_Query(array(
					'post_type' => 'point-table',
					'meta_key' => 'total_points',
					'orderby' => 'meta_value_num',
					'posts_per_page' => $pointtable_result,
					'order' => 'DSC',										
					'tax_query' => array(
				        array(
				            'taxonomy' => 'league-category',
				            'field' => 'slug', //can be set to ID
				            'terms' => $arr_cats//if field is ID you can reference by cat/term number
				        ),
				    )
				));
			}	

			$x = 1;
       			if( $best_wp->have_posts() ): while( $best_wp->have_posts() ) : $best_wp->the_post(); //start while loop

					$clubname     = get_post_meta( get_the_ID(), 'team_point',true );
					
					
					$post_title   = get_the_title($best_wp->ID);			  
					
					$post_img_url = get_the_post_thumbnail_url($best_wp->ID,'full');
					$post_url     =get_post_permalink($best_wp->ID); 
					$won          = get_post_meta( get_the_ID($best_wp->ID), 'game_won',true );
					$lost         = get_post_meta( get_the_ID($best_wp->ID), 'game_lost',true );
					$points       = get_post_meta( get_the_ID($best_wp->ID), 'total_points',true );
				$team_logo = '';
			    if(!empty($clubname)){
			    	    $team_query = new WP_Query( array(
			    	        'post_type' => 'club',
			    	        'post_status' => 'publish',
			    	        'p' => $clubname,
			    	    ));

			    	    if ( $team_query->have_posts() ) :
			    	        while ( $team_query->have_posts() ) :
			    	            $team_query->the_post();					            	
			    	            $team_logo = get_the_post_thumbnail($best_wp->ID);    
			    	        endwhile;
			    	        wp_reset_query();			    	        
			    	       
			    	    endif;
			    	}


				$tr_border = '';
                $logo = '';
                $first_row = "";
                if($show_tem_logo == 'yes'){ 
                    $tr_border = 'row_border';
                    $logo = $team_logo;
                }else{
                    $first_row = '<td>'.$x.'</td>';
                }
		
						
				$html .='				

                   <tr class="'.$tr_border.'">
                   		'.$first_row.'
                   		<td>'.$logo.' '.find_club($clubname).'</td>';
                        $html .='                                   		
                   		
                   		<td>'.$won.'</td>
                   		<td>'.$lost.'</td>
                   	
                   		<td>'.$points.'</td>
                   </tr>';                                          

					$x++;
						endwhile; 
				wp_reset_query();
			endif;
			
		$html .= '
		</table>

		</div>
		</div>';		
	  return $html; 
    }

}

add_shortcode( 'vc_pointtable', 'vc_Portfolio_html' );  